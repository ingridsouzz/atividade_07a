﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");

using System;

namespace Atividade_07a
{
    class Program
    {
        static void  Main(string[] args)
        {
            Pessoa_Fisica pf = new Pessoa_Fisica();
            float val_pag;
            Console.WriteLine("Informar nome");
            string var_nome = Console.ReadLine();
            Console.WriteLine ("Informar endereco");
            string var_endereco = Console.ReadLine();
            Console.WriteLine("Pessoa Física(f) Pessoa Jurídica(j)");
            string var_tipo = Console.ReadLine();
            if (var_tipo == "f")
            {
                //- - - Pessoa Física - - -
                Pessoa_Fisica pfis = new Pessoa_Fisica();
                pfis.nome = var_nome;
                pfis.endereco = var_endereco;
                Console.WriteLine("Informar CPf: ");
                pfis.cpf = Console.ReadLine();
                Console.WriteLine("Informar RG: ");
                pfis.rg = Console.ReadLine();
                Console.WriteLine("Informar o valor de compra:");
                val_pag = float.Parse(Console.ReadLine());
                pfis.Pagar_Imposto(val_pag);
                Console.WriteLine("-----Pessoa Fisica------");
                Console.WriteLine("Nome..............: " + pfis.nome);
                Console.WriteLine("Endereco..........: " + pfis.endereco);
                Console.WriteLine("CPF...............: " + pfis.cpf);
                Console.WriteLine("RG................: " + pfis.rg);
                Console.WriteLine("Valor de Compra...: " + pfis.valor.ToString("C"));
                Console.WriteLine("Imposto...........: " + pfis.valor_imposto.ToString("C"));
                Console.WriteLine("Total a Pagar.....: " + pfis.total.ToString("C"));
            }
            if (var_tipo == "j")
            {
                //- - - Pessoa Juridica - - -
                Pessoa_Juridica pj = new Pessoa_Juridica();
                pj.nome = var_nome;
                pj.endereco = var_endereco;
                Console.WriteLine("Informar CNPJ: ");
                pj.cnpj = Console.ReadLine();
                Console.WriteLine("Informar IE: ");
                pj.ie = Console.ReadLine();
                Console.WriteLine("Informar o valor de compra:");
                val_pag = float.Parse(Console.ReadLine());
                pj.Pagar_Imposto(val_pag);
                Console.WriteLine("-----Pessoa Fisica------");
                Console.WriteLine("Nome..............: " + pj.nome);
                Console.WriteLine("Endereco..........: " + pj.endereco);
                Console.WriteLine("CNPJ...............: " + pj.cnpj);
                Console.WriteLine("IE................: " + pj.ie);
                Console.WriteLine("Valor de Compra...: " + pj.valor.ToString("C"));
                Console.WriteLine("Imposto...........: " + pj.valor_imposto.ToString("C"));
                Console.WriteLine("Total a Pagar.....: " + pj.total.ToString("C"));
            }
        }
    }
}