namespace Atividade_07a
{
    class Pessoa_Fisica : Clientes
    {
        public string cpf {get; set;}
        public string rg {get; set;}
    }
}